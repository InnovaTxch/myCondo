import 'package:flutter/material.dart';
import 'package:mycondo/theme/app_theme.dart';
import 'package:mycondo/data/models/payment_item.dart';
import 'package:mycondo/data/repositories/manager/payment_approval_repository.dart';
import 'package:mycondo/features/manager/widgets/payment_card.dart';
import 'package:mycondo/utils/app_snackbar.dart';
import 'package:mycondo/features/shared/widgets/app_states.dart';

class ApprovePaymentsScreen extends StatefulWidget {
  const ApprovePaymentsScreen({super.key});

  @override
  State<ApprovePaymentsScreen> createState() => _ApprovePaymentsScreenState();
}

class _ApprovePaymentsScreenState extends State<ApprovePaymentsScreen> {
  final PaymentApprovalRepository _repository = PaymentApprovalRepository();
  PaymentStatus selectedTab = PaymentStatus.pending;
  late Future<List<PaymentItem>> _paymentsFuture;

  @override
  void initState() {
    super.initState();
    _paymentsFuture = _repository.getPayments(selectedTab);
  }

  Future<void> _loadPayments() async {
    final future = _repository.getPayments(selectedTab);
    setState(() {
      _paymentsFuture = future;
    });
    await future;
  }

  void _setSelectedTab(PaymentStatus status) {
    setState(() {
      selectedTab = status;
      _paymentsFuture = _repository.getPayments(selectedTab);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFDDEFFC),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.chevron_left, color: Colors.black),
                  label: const Text(
                    'Back',
                    style: TextStyle(
                      fontFamily: "Urbanist",
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                      height: 1.0,
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(14, 18, 14, 16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEAF4FB),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        'Approve Payments',
                        style: TextStyle(
                          fontFamily: "Urbanist",
                          fontSize: 24,
                          fontWeight: FontWeight.w500,
                          color: Colors.black,
                          height: 1.0,
                        ),
                      ),
                      const SizedBox(height: 14),
                      _buildTabs(),
                      const SizedBox(height: 14),
                      Expanded(
                        child: FutureBuilder<List<PaymentItem>>(
                          future: _paymentsFuture,
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const AppLoadingState();
                            }

                            if (snapshot.hasError) {
                              return AppErrorState(
                                message: 'Unable to load payments. Try again.',
                                details: '${snapshot.error}',
                                onRetry: _loadPayments,
                              );
                            }

                            final payments =
                                snapshot.data ?? const <PaymentItem>[];
                            if (payments.isEmpty) {
                              return const AppEmptyState(
                                icon: Icons.payments_outlined,
                                title: 'No payments found',
                                message: 'Payments will appear here when residents submit them.',
                                card: false,
                              );
                            }

                            return RefreshIndicator(
                              onRefresh: _loadPayments,
                              child: ListView.builder(
                                itemCount: payments.length,
                                itemBuilder: (context, index) {
                                  final payment = payments[index];
                                  return PaymentCard(
                                    payment: payment,
                                    onApprove: () => _approve(payment),
                                    onReject: () => _reject(payment),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabs() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF2F2F2),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _tabItem('Pending', PaymentStatus.pending),
          _tabItem('Approved', PaymentStatus.approved),
          _tabItem('Rejected', PaymentStatus.rejected),
        ],
      ),
    );
  }

  Widget _tabItem(String label, PaymentStatus status) {
    final isSelected = selectedTab == status;

    return GestureDetector(
      onTap: () => _setSelectedTab(status),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontFamily: "Urbanist",
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.primaryBlue,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 4),
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 2,
            width: isSelected ? 40 : 0,
            decoration: BoxDecoration(
              color: AppColors.primaryBlue,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _approve(PaymentItem payment) async {
    final confirmed = await _confirmAction(
      title: 'Approve Payment',
      message:
          'Approve this payment from ${payment.residentName}? This will apply it to the bill balance.',
      actionLabel: 'Approve',
    );
    if (!confirmed) return;

    try {
      await _repository.approvePayment(payment);
      await _loadPayments();
    } catch (e) {
      if (!mounted) return;
      context.showAppSnackBar(SnackBar(content: Text('Approve failed: $e')));
    }
  }

  Future<void> _reject(PaymentItem payment) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (context) => const _RejectPaymentDialog(),
    );
    if (reason == null) return;

    final confirmed = await _confirmAction(
      title: 'Deny Payment',
      message:
          'Deny this payment from ${payment.residentName}? The reason will be shown to the resident.',
      actionLabel: 'Deny',
      isDestructive: true,
    );
    if (!confirmed) return;

    try {
      await _repository.rejectPayment(
        payment: payment,
        reason: reason,
      );
      await _loadPayments();
    } catch (e) {
      if (!mounted) return;
      context.showAppSnackBar(SnackBar(content: Text('Reject failed: $e')));
    }
  }

  Future<bool> _confirmAction({
    required String title,
    required String message,
    required String actionLabel,
    bool isDestructive = false,
  }) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  isDestructive ? const Color(0xFFB3261E) : null,
              foregroundColor: isDestructive ? Colors.white : null,
            ),
            child: Text(actionLabel),
          ),
        ],
      ),
    );

    return confirmed == true;
  }
}

class _RejectPaymentDialog extends StatefulWidget {
  const _RejectPaymentDialog();

  @override
  State<_RejectPaymentDialog> createState() => _RejectPaymentDialogState();
}

class _RejectPaymentDialogState extends State<_RejectPaymentDialog> {
  final _controller = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Deny Payment'),
      content: TextField(
        controller: _controller,
        minLines: 3,
        maxLines: 5,
        decoration: InputDecoration(
          labelText: 'Reason',
          errorText: _error,
          border: const OutlineInputBorder(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            final reason = _controller.text.trim();
            if (reason.isEmpty) {
              setState(() => _error = 'Reason is required.');
              return;
            }
            Navigator.pop(context, reason);
          },
          child: const Text('Deny'),
        ),
      ],
    );
  }
}

