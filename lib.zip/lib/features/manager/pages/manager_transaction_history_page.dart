import 'package:flutter/material.dart';
import 'package:mycondo/theme/app_theme.dart';
import 'package:mycondo/data/models/payment_item.dart';
import 'package:mycondo/data/repositories/manager/payment_approval_repository.dart';
import 'package:mycondo/features/manager/widgets/payment_card.dart';
import 'package:mycondo/features/shared/widgets/app_states.dart';

class ManagerTransactionHistoryPage extends StatefulWidget {
  const ManagerTransactionHistoryPage({super.key});

  @override
  State<ManagerTransactionHistoryPage> createState() =>
      _ManagerTransactionHistoryPageState();
}

class _ManagerTransactionHistoryPageState
    extends State<ManagerTransactionHistoryPage> {
  final PaymentApprovalRepository _repository = PaymentApprovalRepository();
  late Future<List<PaymentItem>> _paymentsFuture;

  @override
  void initState() {
    super.initState();
    _paymentsFuture = _repository.getProcessedPayments();
  }

  Future<void> _refresh() async {
    final future = _repository.getProcessedPayments();
    setState(() {
      _paymentsFuture = future;
    });
    await future;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.lightBlueBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Payment History',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  color: AppColors.darkText,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Approved and denied payments',
                style: TextStyle(color: Color(0xFF777777)),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: FutureBuilder<List<PaymentItem>>(
                  future: _paymentsFuture,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const AppLoadingState();
                    }

                    if (snapshot.hasError) {
                      return AppErrorState(
                        message: 'Unable to load transactions: ${snapshot.error}',
                      );
                    }

                    final payments = snapshot.data ?? const <PaymentItem>[];
                    if (payments.isEmpty) {
                      return RefreshIndicator(
                        onRefresh: _refresh,
                        child: ListView(
                          physics: const AlwaysScrollableScrollPhysics(),
                          children: const [
                            SizedBox(height: 120),
                            AppEmptyState(
                              title: 'No payments yet',
                              message: 'No processed payments yet.',
                              icon: Icons.receipt_long_outlined,
                              card: false,
                            ),
                          ],
                        ),
                      );
                    }

                    return RefreshIndicator(
                      onRefresh: _refresh,
                      child: ListView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.only(bottom: 24),
                        itemCount: payments.length,
                        itemBuilder: (context, index) {
                          return PaymentCard(payment: payments[index]);
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


